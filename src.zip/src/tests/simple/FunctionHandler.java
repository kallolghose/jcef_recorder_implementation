package tests.simple;

import org.cef.browser.CefBrowser;
import org.cef.callback.CefQueryCallback;
import org.cef.handler.CefMessageRouterHandlerAdapter;

public class FunctionHandler extends CefMessageRouterHandlerAdapter
{
	 @Override
	    public boolean onQuery(CefBrowser browser, long query_id, String request, boolean persistent,
	            CefQueryCallback callback) {
		 	System.out.println("Request : " + request);
	        if (request.equals("BindingTest")) 
	        {
	            callback.success("Success From Java");
	            return true;
	        }
	        else if (request.equals("ClickEvent")) 
	        {
	        	System.out.println("Hello From Click");
	            callback.success("Success From Java");
	            return true;
	        }
	        else
	        {
	        	callback.failure(404, "Error from Java");
	        	return true;
	        }
	        //return false;
	    }
}
