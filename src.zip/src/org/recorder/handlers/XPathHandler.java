package org.recorder.handlers;

import org.cef.browser.CefBrowser;
import org.cef.callback.CefQueryCallback;
import org.cef.handler.CefMessageRouterHandlerAdapter;

public class XPathHandler extends CefMessageRouterHandlerAdapter
{
	@Override
	public boolean onQuery(CefBrowser browser, long query_id, String request, boolean persistent, CefQueryCallback callback)
	{
		System.out.println("Request : \n" + request);
		callback.success("Success From Java");
		return true;
	}
}
