package org.recorder.automatics;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

import org.cef.CefApp;

public class Recorder extends JFrame
{
	private static final long serialVersionUID = 1L;

	public static void main(String[] args)
	{
		Recorder frame = new Recorder();
		frame.add(new BrowserPanel("file:///D:/check.html",false,false));
		frame.setSize(800, 600);
		frame.setVisible(true);
		frame.addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        CefApp.getInstance().dispose();
		        frame.dispose();
		    }
		});
	}
}
