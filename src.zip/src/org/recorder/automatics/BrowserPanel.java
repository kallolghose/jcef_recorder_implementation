package org.recorder.automatics;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicArrowButton;
import javax.swing.text.html.StyleSheet.BoxPainter;

import org.cef.CefApp;
import org.cef.CefClient;
import org.cef.CefSettings;
import org.cef.CefApp.CefAppState;
import org.cef.browser.CefBrowser;
import org.cef.browser.CefMessageRouter;
import org.cef.handler.CefAppHandlerAdapter;
import org.cef.handler.CefDisplayHandlerAdapter;
import org.cef.handler.CefLoadHandlerAdapter;
import org.recorder.handlers.XPathHandler;

public class BrowserPanel extends JPanel
{
	private static final long serialVersionUID = 1L;
	private final JTextField address_;
    private final CefApp cefApp_;
    private final CefClient client_;
    private final CefBrowser browser_;
    private final Component browserUI_;
    private final BasicArrowButton back;
    private final BasicArrowButton forward;

	public BrowserPanel(String startURL, boolean useOSR, boolean isTransparent)
	{
		CefApp.addAppHandler(new CefAppHandlerAdapter(null) {
            @Override
            public void stateHasChanged(org.cef.CefApp.CefAppState state) {
                // Shutdown the app if the native CEF part is terminated
                if (state == CefAppState.TERMINATED) System.exit(0);
            }
        });
        CefSettings settings = new CefSettings();
        settings.windowless_rendering_enabled = useOSR;
        cefApp_ = CefApp.getInstance(settings);
        client_ = cefApp_.createClient();
        browser_ = client_.createBrowser(startURL, useOSR, isTransparent);

        browserUI_ = browser_.getUIComponent();

        client_.addDisplayHandler(new CefDisplayHandlerAdapter() {
	    	 @Override
	         public void onAddressChange(CefBrowser browser, String url) {
	             address_.setText(url);
	         }
	         @Override
	         public void onTitleChange(CefBrowser browser, String title) {
	         }
	         @Override
	         public void onStatusMessage(CefBrowser browser, String value) {
	         }
		});

        client_.addLoadHandler(new CefLoadHandlerAdapter() {
       	 	@Override
       	 	public void onLoadingStateChange(CefBrowser browser, boolean isLoading,boolean canGoBack, boolean canGoForward)
       	 	{
       	 		back.setEnabled(canGoBack);
       	 		forward.setEnabled(canGoForward);
            }

            @Override
            public void onLoadError(CefBrowser browser, int frameIdentifer, ErrorCode errorCode, String errorText, String failedUrl)
            {}

            @Override
            public void onLoadEnd(CefBrowser browser, int identifier, int data)
            {
            	/*
            	 * Code to add the javascript to handle the operation
            	 * */
            	if(data!=0)
            	{
            		String js = getContentsOfJavaScripts();
            		//browser.executeJavaScript("alert('Hello');", "", 0);
            		/*browser.executeJavaScript("var jq = document.createElement('script'); "
            				+ "\n jq.src = \"https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js\"; "
            				+ "\n document.getElementsByTagName('head')[0].appendChild(jq);", "", 0);
            				*/
            		browser.executeJavaScript(js, "", 0);
            	}
            }
		});

        //Javascript to JAVA handler
        CefMessageRouter router = CefMessageRouter.create();
        router.addHandler(new XPathHandler(), true);
        client_.addMessageRouter(router);


        address_ = new JTextField(" ",100);
        address_.setMinimumSize(new Dimension(5, 200));
        address_.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                browser_.loadURL(address_.getText());
            }
        });


        /*
         * Create Panel to add address bar and the required components to the top
         * */
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
        //Backwards Button
        back = new BasicArrowButton(BasicArrowButton.WEST);
        back.setPreferredSize(new Dimension(5,5));
        back.setMaximumSize(new Dimension(5,5));
        back.setAlignmentX(Component.LEFT_ALIGNMENT);
        back.setEnabled(false);
        back.addActionListener(new ActionListener()
        {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if(browser_.canGoBack())
					browser_.goBack();
			}
		});

        //Forward Button
        forward = new BasicArrowButton(BasicArrowButton.EAST);
        forward.setPreferredSize(new Dimension(5,5));
        forward.setMaximumSize(new Dimension(5,5));
        forward.setAlignmentX(Component.LEFT_ALIGNMENT);
        forward.setEnabled(false);
        forward.addActionListener(new ActionListener()
        {
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if(browser_.canGoForward())
					browser_.goForward();
			}
		});

        address_.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(back);
        panel.add(Box.createHorizontalStrut(2));
        panel.add(forward);
        panel.add(Box.createHorizontalStrut(2));
        panel.add(address_);

        setLayout(new BorderLayout());
        add(panel, BorderLayout.NORTH);
        add(browserUI_, BorderLayout.CENTER);
        //add(new JButton("Click Me !!!"), BorderLayout.CENTER);
        validate();
        setSize(800, 600);
        setVisible(true);
	}

	private String getContentsOfJavaScripts()
	{
		try
		{
			//ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			//InputStream is = classLoader.getResourceAsStream("D:/KG00360770/ATT/EclipseFX/Recorder_Automatics/res/jsCodeToBeinjected.txt");
			BufferedReader reader = new BufferedReader(new FileReader(new File("D:/KG00360770/ATT/EclipseFX/Recorder_Automatics/res/jsCodeToBeinjected.txt")));
			String data = "", temp = "";
			while((temp=reader.readLine())!=null)
			{
				data = data + temp + "\n";
			}
			reader.close();
			return data;
		}
		catch(Exception e)
		{
			System.out.println("Exception : " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

}
